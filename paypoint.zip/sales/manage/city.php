<?php
$page_security = 'SA_CUSTOMER';
$path_to_root = "../..";
include($path_to_root . "/includes/session.inc");

page(_($help_context = "Add City"));

include($path_to_root . "/includes/ui.inc");

simple_page_mode(true);
//------------------------------------------------------------------------------------------------

if ($Mode=='ADD_ITEM' || $Mode=='UPDATE_ITEM')
{

    //initialise no input errors assumed initially before we test
    $input_error = 0;

    if (strlen($_POST['city_name']) == 0)
    {
        $input_error = 1;
        display_error(_("The City name cannot be empty."));
        set_focus('city_name');
    }
    if ($input_error != 1)
    {
        if ($selected_id != -1)
        {
            /*selected_id could also exist if submit had not been clicked this code would not run in this case cos submit is false of course  see the delete code below*/
            update_city($selected_id, $_POST['city_name']);
        }
        else
        {
            /*Selected group is null cos no item selected on first time round so must be adding a record must be submitting new entries in the new Sales-person form */
            add_city($_POST['city_name']);
        }

        if ($selected_id != -1)
            display_notification(_('Selected city name data have been updated'));
        else
            display_notification(_('New city name data have been added'));
        $Mode = 'RESET';
    }
}
if ($Mode == 'Delete')
{
//    the link to delete a selected record was clicked instead of the submit button
//
//     PREVENT DELETES IF DEPENDENT RECORDS IN 'debtors_master'

//    if (key_in_foreign_table($selected_id, '', ''))
//    {
//        display_error(_("Cannot delete this sales-person because branches are set up referring to this sales-person - first alter the branches concerned."));
//    }
//    else
    {
        delete_city($selected_id);
        display_notification(_('Selected city name data have been deleted'));
    }
    $Mode = 'RESET';
}

if ($Mode == 'RESET')
{
    $selected_id = -1;
    $sav = get_post('show_inactive');
    unset($_POST);
    $_POST['show_inactive'] = $sav;
}
//------------------------------------------------------------------------------------------------

$result = get_city(check_value('show_inactive'));

start_form();
start_table(TABLESTYLE, "width=45%");
$th = array(_("City ID"), _("City Name"),"","");
inactive_control_column($th);
table_header($th);

$k = 0;

while ($myrow = db_fetch($result))
{

    alt_table_row_color($k);

    label_cell($myrow["id"]);
    label_cell($myrow["city_name"]);
    inactive_control_cell($myrow["id"], $myrow["inactive"], 'city', 'id');
    edit_button_cell("Edit".$myrow["id"], _("Edit"));
    delete_button_cell("Delete".$myrow["id"], _("Delete"));
    end_row();

} //END WHILE LIST LOOP

inactive_control_row($th);
end_table();
echo '<br>';

//------------------------------------------------------------------------------------------------

if ($selected_id != -1)
{
    if ($Mode == 'Edit') {
        //editing an existing Sales-person
        $myrow =  get_cities($selected_id);

//        $_POST['id'] = $myrow["id"];
        $_POST['city_name'] = $myrow["city_name"];

    }
    hidden('selected_id', $selected_id);
} elseif ($Mode != 'ADD_ITEM') {
}

start_table(TABLESTYLE2);

text_row_ex(_("Add City:"),'city_name', 40);


end_table(1);

submit_add_or_update_center($selected_id == -1, '', 'both');

end_form();

end_page();

?>
