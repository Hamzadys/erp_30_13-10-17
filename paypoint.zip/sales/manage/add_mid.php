<?php
$page_security = 'SA_CUSTOMER';
$path_to_root = "../..";
include($path_to_root . "/includes/session.inc");

page(_($help_context = "Add MID"));

include($path_to_root . "/includes/ui.inc");

simple_page_mode(true);
//------------------------------------------------------------------------------------------------


function get_merchant_name123($id)
{
    $sql = 'SELECT merchant_name from 0_merchant where id='.$id;
    $db = db_query($sql);
    $ft = db_fetch($db);
    return $ft[0];
}

function check_midd($description)
{
    $sql = "SELECT mid from 0_mid WHERE  mid = ".db_escape($description);
    $db = db_query($sql,"asdsads");
    return db_fetch($db);
}

if ($Mode=='ADD_ITEM' || $Mode=='UPDATE_ITEM')
{

    //initialise no input errors assumed initially before we test
    $input_error = 0;

    if (strlen($_POST['merchant_id']) == 0)
    {
        $input_error = 1;
        display_error(_("The merchant name cannot be empty."));
        set_focus('merchant_name');
    }


    if ($input_error != 1)
    {
        if ($selected_id != -1)
        {
            $duplicate = check_midd($_POST['mid']);
            if($_POST['mid'] == $duplicate['mid'])
                display_error(_("Duplicated MID."));
            else
             update_mid_merchant($selected_id, $_POST['merchant_id'], $_POST['mid']);
        }
        else
        {
            $duplicate = check_midd($_POST['mid']);
            if($_POST['mid'] == $duplicate['mid'])
                display_error(_("Duplicated MID."));
            else
           add_mid_merchant($_POST['merchant_id'], $_POST['mid']);


            /*Selected group is null cos no item selected on first time round so must be adding a record must be submitting new entries in the new Sales-person form */
        }

        if ($selected_id != -1)
            display_notification(_('Selected sales person data have been updated'));
        else
            display_notification(_('New sales person data have been added'));
        $Mode = 'RESET';
    }
}
if ($Mode == 'Delete')
{
    //the link to delete a selected record was clicked instead of the submit button

    // PREVENT DELETES IF DEPENDENT RECORDS IN 'debtors_master'

//    if (key_in_foreign_table($selected_id, 'cust_branch', 'salesman'))
//    {
//        display_error(_("Cannot delete this sales-person because branches are set up referring to this sales-person - first alter the branches concerned."));
//    }
//    else
    {
        delete_mid_merchant($selected_id);
        display_notification(_('Selected merchant data have been deleted'));
    }
    $Mode = 'RESET';
}

if ($Mode == 'RESET')
{
    $selected_id = -1;
    $sav = get_post('show_inactive');
    unset($_POST);
    $_POST['show_inactive'] = $sav;
}
//------------------------------------------------------------------------------------------------

$result = get_mid_merchant(check_value('show_inactive'));

start_form();
start_table(TABLESTYLE, "width=40%");
$th = array(_("id"),_("Merchant Name"), _("MID"),"","");
inactive_control_column($th);
table_header($th);

$k = 0;

while ($myrow = db_fetch($result))
{

    alt_table_row_color($k);

    label_cell($myrow["id"]);
    label_cell(get_merchant_name123($myrow["merchant_id"]));
    label_cell($myrow["mid"]);
    inactive_control_cell($myrow["id"], $myrow["inactive"], 'mid', 'id');
    edit_button_cell("Edit".$myrow["id"], _("Edit"));
    delete_button_cell("Delete".$myrow["id"], _("Delete"));
    end_row();

} //END WHILE LIST LOOP

inactive_control_row($th);
end_table();
echo '<br>';

//------------------------------------------------------------------------------------------------


if ($selected_id != -1)
{
    if ($Mode == 'Edit') {
        //editing an existing Sales-person
        $myrow = get_mid_merchants($selected_id);

        $_POST['merchant_id'] = $myrow["merchant_id"];
        $_POST['mid'] = $myrow["mid"];

    }
    hidden('selected_id', $selected_id);
}

start_table(TABLESTYLE2);


//text_row_ex(_("Merchant name:"), 'merchant_name', 40);
merchant_name_list_cells(_("Mechant :"),'merchant_id', null);
//city_row(_("City :"), 'city', $_POST['city_name']);
text_row_ex(_("MID :"), 'mid', '');
//text_row_ex(_("MID:"), 'mid', 40);
//text_row_ex(_("TID:"), 'tid', 40);
end_table(1);

submit_add_or_update_center($selected_id == -1, '', 'both');

end_form();

end_page();

?>
