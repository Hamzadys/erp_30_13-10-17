<?php


class AntErpChart {
	
	public function __construct() {
				
	}

	/**
	 * To generate the graph/data into FrontAccounting
	 * $module			-	Module Name
	 * $param			-	Parameters
	 * $is_graph		-	true  - Render Graph
	 * 						false - Render Data
	 * $return			- 	Array Object
	 */
	public function api($module, $params, $is_graph =  true) {
		global $path_to_root;
				
		if ($is_graph) { //Generate Graph			
			
			switch ($module) {
			    case "orders":
			    	echo '<div align="center"><br/><iframe src="modules/dashboard/charts/top-10-customer-in-fiscal-year.php?source=top10customerinfiscalyear" width="50%" height="700px" frameborder="0" marginheight="0" marginwidth="0"></iframe></div>';
			        break;
			    case "AP":
			    	echo '<div align="center"><br/><iframe src="modules/dashboard/charts/top-10-supplier-in-fiscal-year.php?source=top10supplierinfiscalyear" width="50%" height="700px" frameborder="0" marginheight="0" marginwidth="0"></iframe></div>';
			        break;
			    case "stock":
			    	echo '<div align="center"><br/><iframe src="modules/dashboard/charts/top-10-item-inventory-in-fiscal-year.php?source=top10iteminfiscalyear" width="50%" height="700px" frameborder="0" marginheight="0" marginwidth="0"></iframe></div>';
			        break;       
			    case "manuf":
			    	echo '<div align="center"><br/><iframe src="modules/dashboard/charts/top-10-manufacture-in-fiscal-year.php?source=top10iteminfiscalyear&&manuf=true" width="50%" height="700px" frameborder="0" marginheight="0" marginwidth="0"></iframe></div>';
			        break;
			     case "proj":
			    	echo '<div align="center"><br/><iframe src="modules/dashboard/charts/top-10-dimension-in-fiscal-year.php?source=top10dimensionfiscalyear" width="50%" height="700px" frameborder="0" marginheight="0" marginwidth="0"></iframe></div>';
			        break;
			     case "GL":
			    	echo '<div align="center"><br/><iframe src="modules/dashboard/charts/gl-in-fiscal-year.php?source=glfiscalyear" width="50%" height="700px" frameBorder="0" marginheight="0" marginwidth="0"></iframe></div>';
			        break;
			     case "dashboard":			      	
			      	include_once($path_to_root.'/modules/dashboard/dashboard.php');
			        break;
			     case "system":			      	
			      	echo '<div align="center"><br/><table width="50%" height="700px">';
			      	$title = "This page is intention to leave empty.";
					br(2);
					display_heading($title);
			      	echo '</table></div>';
			        break;     
			     default:
			     	{
					$title = "Display System Diagnostics";
					br(2);
					display_heading($title);
					br();
					display_system_tests();
					br(2);
				}
	    	}		
			
		} else { // Render Data Only
		}
	}
}
?>