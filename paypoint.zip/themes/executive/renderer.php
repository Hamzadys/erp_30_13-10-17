<?php

	class renderer
	{
		function wa_header()
		{
			page(_($help_context = "Main Menu"), false, true);
		}

		function wa_footer()
		{
			end_page(false, true);
		}
	 
		function menu_header($title, $no_menu, $is_index)
		{
			global $path_to_root, $help_base_url, $power_by, $version, $db_connections, $installed_extensions;

			$sel_app = $_SESSION['sel_app'];
			echo "<div class='fa-main'>\n";
			if (!$no_menu)
			{
				$applications = $_SESSION['App']->applications;
	
				$img = "<img src='$path_to_root/themes/".user_theme(). "/images/login.gif' width='14' height='14' border='0' alt='"._('Logout')."'>&nbsp;&nbsp;";
				$himg = "<img src='$path_to_root/themes/".user_theme(). "/images/help.gif' width='14' height='14' border='0' alt='"._('Help')."'>&nbsp;&nbsp;";
				echo "<div id='header'>\n";
				echo "<ul>\n";
				echo "  <li><a href='$path_to_root/admin/display_prefs.php?'>" . _("Configuration") . "</a></li>\n";
				echo "  <li><a href='$path_to_root/admin/change_current_user_password.php?selected_id=" . $_SESSION["wa_current_user"]->username . "'>" . _("Change password") . "</a></li>\n";
			 	if ($help_base_url != null)
					echo "  <li><a target = '_blank' onclick=" .'"'."javascript:openWindow(this.href,this.target); return false;".'" '. "href='". 
						help_url()."'>$himg" . _("Help") . "</a></li>";
				echo "  <li><a href='$path_to_root/access/logout.php?'>$img" . _("Logout") . "</a></li>";
				echo "  </br></br><li><a href=''>" . _("Helpline +92 321 2600082 & +92 21 34330907") . "</a></li>";
				echo "</ul>\n";
				$indicator = "$path_to_root/themes/".user_theme(). "/images/ajax-loader.gif";
				echo "<br><h1>$power_by<span style='padding-left:300px;'><img id='ajaxmark' src='$indicator' align='center' style='visibility:hidden;'></span></h1>\n";
				echo "<br></div>\n"; // header
				echo "<div class='clear'></div>\n";
			}				

			// These part is to render all the css stylesheet
			echo '<link rel="stylesheet" type="text/css" href="' . $path_to_root . '/themes/'.user_theme(). '/nav.css" />';
			echo '<link rel="stylesheet" type="text/css" href="' . $path_to_root . '/themes/'.user_theme(). '/widget-styles.css" />';
			echo '<link rel="stylesheet" type="text/css" href="' . $path_to_root . '/js/thickbox/thickbox.css" />';			
			echo '<link rel="stylesheet" type="text/css" href="' . $path_to_root . '/js/jquery/jquery-ui/css/smoothness/jquery-ui-1.8.16.custom.css"/>';			

			//!TODO These 2 need to be uncomment if you are running your FrontAccounting in Local Server WITHOUT internet access
			//echo '<script type="text/javascript" src="' .$path_to_root. '/js/jquery/jquery-1.6.4.min.js"></script>';
			//echo '<script type="text/javascript" src="' .$path_to_root. '/js/jquery/jquery-ui-1.8.16.custom.min.js"></script>';

			//These 2 library are using google api directly connected to the internet
			echo '<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>';
			echo '<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js"></script>';
			
			//These part is the render Top menu
			echo '<script type="text/javascript" src="' .$path_to_root. '/js/jquery/superfish.js"></script>';
			echo '<script type="text/javascript" src="' .$path_to_root. '/js/jquery/hoverIntent.js"></script>';
			//These part is to render the Dashboard using Jquery related libraries
			echo '<script type="text/javascript" src="' .$path_to_root. '/js/jquery/jquery.json-2.3.min.js"></script>';			
			echo '<script type="text/javascript" src="' .$path_to_root. '/js/jquery/tooltip.js"></script>';
			echo '<script type="text/javascript" src="' .$path_to_root. '/js/thickbox/thickbox-compressed.js"></script>';
			echo '<script type="text/javascript" src="' .$path_to_root. '/modules/dashboard/dashboard.js"></script>';			
			echo '<script type="text/javascript" src="' . $path_to_root . '/js/jquery/function.js"></script>';
			//These part is to render the SuperFish Dynamic Menu
			echo renderSuperFishJavaScript();

			if (!$no_menu)
			{		
			add_access_extensions();
			$applications = $_SESSION['App']->applications;

			echo "<div id='menu'>";
			echo "<ul class='nav left'>";
			
			//Applications Top Menu
			foreach($applications as $app)
				{
					$acc = access_string_custom($app->name);					
					echo "<li><a class='top' href='$path_to_root/index.php?application=" . $app->id ."'><b>" . $acc[0] . "</b></a>";
					echo "<ul>";
					
					//Modules
					foreach ($app->modules as $module)
					{
						
						if (isset($module->name)) {// If parent
							echo "<li><a class='parent'>" . $module->name . "</a>";
							 echo "<ul>";
						}
						
						$apps = array();
						if (count($module->lappfunctions) > 0) {
							foreach ($module->lappfunctions as $appfunction)
								$apps[] = $appfunction;
						}
						foreach ($module->rappfunctions as $appfunction)
							$apps[] = $appfunction;
						$application = array();	
						foreach ($apps as $application)	
						{
							$lnk = access_string_custom($application->label);
							if ($_SESSION["wa_current_user"]->can_access_page($application->access))
							{
								if ($application->label != "")
								{		
									echo "<li><a href='$path_to_root/$application->link' title='" . $lnk[0]  ."'>" . $lnk[0] ."</a></li>";
								}
							}
						}
						
						if (isset($module->name)) { // If parent
								echo "</ul>"; 
						 	echo "</li>";
						}
					}
					
						echo "</ul>";
					echo "</li>";
						
				}
				
				echo "</ul>";
				echo "</div>";
			}
			
			
			if ($no_menu)
				echo "<br>";
			elseif ($title && !$no_menu && !$is_index)
			{
				echo "<center><table id='title'><tr><td width='100%' class='titletext'>$title</td>"
				."<td align=right>"
				.(user_hints() ? "<span id='hints'></span>" : '')
				."</td>"
				."</tr></table></center>";
			}
		}

		function menu_footer($no_menu, $is_index)
		{
			global $path_to_root, $power_url, $power_by, $version, $db_connections;
			include_once($path_to_root . "/includes/date_functions.inc");

			if (!$no_menu)
				echo "</div>\n"; // fa-content
			echo "</div>\n"; // fa-body
			if (!$no_menu)
			{
				echo "<div class='fa-footer'>\n";
				if (isset($_SESSION['wa_current_user']))
				{
					echo "<span class='last'>".Today() . "&nbsp;" . Now()."</span>\n";
					echo "<span class='date'>" . $db_connections[$_SESSION["wa_current_user"]->company]["name"] . "</span>\n";
					echo "<span class='date'>" . $_SERVER['SERVER_NAME'] . "</span>\n";

					echo "<span class='date'>" . $_SESSION["wa_current_user"]->name . "</span>\n";
				}
				echo "</div>\n"; // footer
			}
			echo "</div>\n"; // fa-main
		}

		function display_applications(&$waapp)
		{
			global $path_to_root, $use_popup_windows;
			include($path_to_root . "/includes/system_tests.inc");
			include($path_to_root . "/themes/".user_theme(). "/AntErpChart.php");
			
			$chartapi = new AntErpChart();

			if ($use_popup_windows)
			{
				echo "<script language='javascript'>\n";
				echo get_js_open_window(960, 640);
				echo "</script>\n"; 
			}
			
			$selected_app = $waapp->get_selected_application();
			// first have a look through the directory, 
			// and remove old temporary pdfs and pngs
			$dir = company_path(). '/pdf_files';
	
			if ($d = @opendir($dir)) {
				while (($file = readdir($d)) !== false) {
					if (!is_file($dir.'/'.$file) || $file == 'index.php') continue;
				// then check to see if this one is too old
					$ftime = filemtime($dir.'/'.$file);
				 // seems 3 min is enough for any report download, isn't it?
					if (time()-$ftime > 180){
						unlink($dir.'/'.$file);
					}
				}
				closedir($d);
			}

			$chartapi->api($selected_app->id, null, true);

		}
	}
	
	function access_string_custom($label, $clean=false)
	{
		$access = '';
		$slices = array();
	
		if (preg_match('/(.*)&([a-zA-Z0-9])(.*)/', $label, $slices))	
		{
			$label = $clean ? $slices[1].$slices[2].$slices[3] :
				$slices[1].$slices[2].$slices[3];
			$access = " accesskey='".strtoupper($slices[2])."'";
		}
		
		return $clean ? $label : array($label, $access);
	}
	
	/*
	 * Function to render SuperFish Library
	 */
		function renderSuperFishJavaScript(){

			echo '<script type="text/javascript">
						$(document).ready(function() {
							$(".nav").superfish({
								hoverClass	 : "sfHover",
								pathClass	 : "overideThisToUse",
								delay		 : 0,
								animation	 : {height: "show"},
								speed		 : "normal",
								autoArrows   : false,
								dropShadows  : false, 
								disableHI	 : false, /* set to true to disable hoverIntent detection */
								onInit		 : function(){},
								onBeforeShow : function(){},
								onShow		 : function(){},
								onHide		 : function(){}
							});
														
							$(".nav").css("display", "block");
						});</script>';
	}	
?>