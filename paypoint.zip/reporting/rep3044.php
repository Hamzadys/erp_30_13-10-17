<?php
$page_security = 'SA_SALESANALYTIC';
// ----------------------------------------------------------------
// $ Revision:	2.0 $
// Creator:	Joe Hunt
// date_:	2005-05-19
// Title:	Inventory Sales Report
// ----------------------------------------------------------------
$path_to_root="..";

include_once($path_to_root . "/includes/session.inc");
include_once($path_to_root . "/includes/date_functions.inc");
include_once($path_to_root . "/includes/data_checks.inc");
include_once($path_to_root . "/includes/banking.inc");
include_once($path_to_root . "/gl/includes/gl_db.inc");
include_once($path_to_root . "/inventory/includes/db/items_category_db.inc");

//----------------------------------------------------------------------------------------------------

print_inventory_sales();

function getTransactions($m_name,$mid,$item)
{
	$sql = "SELECT sm.stock_id,  m.merchant_name,mi.mid,smm.tid,c.city_name,
                   smm.p_pos,smm.qty,smm.remarks ,smm.staff_name,pos.pos_status_name
                   ,smm.standard_cost,smm.stock_id2,smm.tid2,smm.tran_date
               
               FROM 0_stock_moves smm 
               left join 0_stock_master sm on smm.stock_id = sm.stock_id 
               left join 0_merchant m on smm.merchant = m.id 
               left join 0_city c on m.city = c.id 
               left join 0_region r on m.region = r.id 
               left join 0_mid mi on m.id = mi.merchant_id 
               left join 0_pos_status pos on smm.pos_type = pos.id 
               left join 0_support_staff ss on smm.staff_name = ss.id 
               left join 0_stock_category sc on sm.category_id = sc.category_id
                
                WHERE sm.inactive = 0 AND smm.form_type='RF' ";


	if($m_name != 0 )
	{
		$sql.=" AND m.id='".$m_name."'";
	}

	if($mid !='')
	{
		$sql.=" AND mi.mid='".$mid."'";
	}


	if($item != 0)
	{
		$sql.=" AND sm.stock_id='".$item."'";
	}
	
	return db_query($sql,"Error");
}

//----------------------------------------------------------------------------------------------------

function print_inventory_sales()
{
    global $path_to_root;
	$m_name = $_POST['PARAM_0'];
	$mid = $_POST['PARAM_1'];
	$item = $_POST['PARAM_2'];
	//$from = $_POST['PARAM_0'];
	//$to = $_POST['PARAM_1'];
//    $category = $_POST['PARAM_2'];
//    $location = $_POST['PARAM_3'];
//    $fromcust = $_POST['PARAM_4'];
//	$comments = $_POST['PARAM_5'];
	//$orientation = $_POST['PARAM_6'];
	$destination = $_POST['PARAM_3'];
	if ($destination)
		include_once($path_to_root . "/reporting/includes/excel_report.inc");
	else
		include_once($path_to_root . "/reporting/includes/pdf_report.inc");

	$orientation = 'L';
    $dec = user_price_dec();

	/*if ($category == ALL_NUMERIC)
		$category = 0;
	if ($category == 0)
		$cat = _('All');
	else
		$cat = get_category_name($category);

	if ($location == '')
		$loc = _('All');
	else
		$loc = get_location_name($location);

	if ($fromcust == '')
		$fromc = _('All');
	else
		$fromc = get_customer_name($fromcust);*/

	$cols = array(0, 30, 110, 160, 205, 245, 300, 330, 360, 395, 430, 450, 490, 530);
	//$cols = array(0, 30, 75, 110, 160, 210, 270, 320, 370, 400, 440, 480, 530, 600);

	$headers = array(_('S.No.'), _('Merchant Name'), _('MID'), _('TID'), _('City'),
		             _('Problematic POS'), _('Quantity'), _('Remarks'),
                     _('Staff Name'), _('POS Type'), _('Cost'), _('S.no 2'),
					_('Tid 2'), _('Trans Date'));


	$aligns = array('left',	'left',	'left', 'left', 'left', 'left', 'left', 'left', 'left');

    $params =   array( //	0 => $comments,
    				 //   1 => array('text' => _('Period'),'from' => $from, 'to' => $to),
    				 //   2 => array('text' => _('Category'), 'from' => $cat, 'to' => ''),
    				//    3 => array('text' => _('Location'), 'from' => $loc, 'to' => ''),
    				  //  4 => array('text' => _('Customer'), 'from' => $fromc, 'to' => '')
		);

    $rep = new FrontReport(_('Replacement Dashboard Report'), "InventorySalesReport", user_pagesize(), 9, $orientation);
   	if ($orientation == 'L')
    	recalculate_cols($cols);

    $rep->Font();
    $rep->Info($params, $cols, $headers, $aligns);
    $rep->NewPage();

	$serial_no = 0;
	$res = getTransactions($m_name,$mid,$item);

	while ($trans = db_fetch($res))
	{
		$serial_no ++;
		$rep->TextCol(0, 1, $trans['stock_id']);
		$rep->TextCol(1, 2, $trans['merchant_name']);
		$rep->TextCol(2, 3, $trans['mid']);
		$rep->TextCol(3, 4, $trans['tid']);
		$rep->TextCol(4, 5, $trans['city_name']);
		$rep->TextCol(5, 6, $trans['p_pos']);
		$rep->TextCol(6, 7, $trans['qty']);
		$rep->TextCol(7, 8, $trans['remarks']);
		$rep->TextCol(8, 9, $trans['staff_name']);
		$rep->TextCol(9, 10, $trans['pos_status_name']);
		$rep->TextCol(10, 11, $trans['standard_cost']);
		$rep->TextCol(11, 12, $trans['stock_id2']);
		$rep->TextCol(12, 13, $trans['tid2']);
		$rep->TextCol(13, 14, $trans['tran_date']);

		$rep->NewLine();
	}
	$rep->NewLine(2, 3);

	$rep->Line($rep->row  - 4);
	$rep->NewLine();
    $rep->End();
}

?>