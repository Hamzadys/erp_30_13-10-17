<?php
$page_security = 'SA_CUSTPAYMREP';

// ----------------------------------------------------------------
// $ Revision:	2.0 $
// Creator:	Joe Hunt
// date_:	2005-05-19
// Title:	Customer Balances
// ----------------------------------------------------------------
$path_to_root="..";

include_once($path_to_root . "/includes/session.inc");
include_once($path_to_root . "/includes/date_functions.inc");
include_once($path_to_root . "/includes/data_checks.inc");
include_once($path_to_root . "/gl/includes/gl_db.inc");
include_once($path_to_root . "/sales/includes/db/customers_db.inc");

//----------------------------------------------------------------------------------------------------
print_customer_balances();
function get_sql_for_deployment_new($serial_no,$mid,$m_name,$city,$model)
{

	  $sql = "SELECT @a:=@a+1 serial_number, m.merchant_name,m.commercial_name, r.region_name,
      c.city_name,m.address,smm.tid,pm.pos_status_name as posmodel,smm.stock_id,smm.sim,smm.tran_date,pos.pos_status_name as status,
                   smm.p_pos,smm.qty,smm.remarks ,smm.staff_name,pos.pos_status_name
                   ,smm.stock_id2,smm.tid2,smm.person_id,mi.mid 
               
               FROM 0_stock_moves smm 
               left join 0_stock_master sm on smm.stock_id = sm.stock_id 
               left join 0_merchant m on smm.merchant = m.id 
               left join 0_city c on m.city = c.id 
               left join 0_region r on m.region = r.id 
               left join 0_mid mi on m.id = mi.merchant_id 
               left join 0_pos_status pos on smm.pos_type = pos.id 
               left join 0_pos_model pm on smm.pos_type = pm.id 
               left join 0_support_staff ss on smm.staff_name = ss.id 
               left join 0_stock_category sc on sm.category_id = sc.category_id, (SELECT @a:= 0) AS a
                
                WHERE sm.inactive = 0 AND smm.form_type='RF' ";

	if($serial_no !='')
	{
		$sql.=" AND sm.stock_id='".$serial_no."'";
	}

	if($mid !='')
	{
		$sql.=" AND mi.mid='".$mid."'";
	}

	if($m_name != 0)
	{
		$sql.=" AND m.id='".$m_name."'";
	}
	if($city != -1)
	{
		$sql.=" AND c.id='".$city."'";
	}

	if($model != 0)
	{
		$sql.=" AND pos.id='".$model."'";
	}




	return db_query($sql,"No transactions were returned");
}
//trial_inquiry_controls();

//
//function get_open_balance($debtorno, $to, $convert)
//{
//	if($to)
//		$to = date2sql($to);
//
//    $sql = "SELECT SUM(IF(t.type = ".ST_SALESINVOICE.",
//    	(t.ov_amount + t.ov_gst + t.ov_freight + t.ov_freight_tax + t.ov_discount)";
//    if ($convert)
//    	$sql .= " * rate";
//    $sql .= ", 0)) AS charges,
//    	SUM(IF(t.type <> ".ST_SALESINVOICE.",
//    	(t.ov_amount + t.ov_gst + t.ov_freight + t.ov_freight_tax + t.ov_discount)";
//    if ($convert)
//    	$sql .= " * rate";
//    $sql .= " * -1, 0)) AS credits,
//		SUM(t.alloc";
//	if ($convert)
//		$sql .= " * rate";
//	$sql .= ") AS Allocated,
//		SUM(IF(t.type = ".ST_SALESINVOICE.",
//			(t.ov_amount + t.ov_gst + t.ov_freight + t.ov_freight_tax + t.ov_discount - t.alloc)";
//    if ($convert)
//    	$sql .= " * rate";
//    $sql .= ",
//    	((t.ov_amount + t.ov_gst + t.ov_freight + t.ov_freight_tax + t.ov_discount) * -1 + t.alloc)";
//    if ($convert)
//    	$sql .= " * rate";
//    $sql .= ")) AS OutStanding
//		FROM ".TB_PREF."debtor_trans t
//    	WHERE t.debtor_no = ".db_escape($debtorno)
//		." AND t.type <> ".ST_CUSTDELIVERY;
//    if ($to)
//    	$sql .= " AND t.tran_date < '$to'";
//	$sql .= " GROUP BY debtor_no";
//
//    $result = db_query($sql,"No transactions were returned");
//    return db_fetch($result);
//}
//
//function get_transactions($debtorno, $from, $to)
//{
//	$from = date2sql($from);
//	$to = date2sql($to);
//
//    $sql = "SELECT ".TB_PREF."debtor_trans.*,
//		(".TB_PREF."debtor_trans.ov_amount + ".TB_PREF."debtor_trans.ov_gst + ".TB_PREF."debtor_trans.ov_freight +
//		".TB_PREF."debtor_trans.ov_freight_tax + ".TB_PREF."debtor_trans.ov_discount + ".TB_PREF."debtor_trans.gst_wh)
//		AS TotalAmount, ".TB_PREF."debtor_trans.alloc AS Allocated,
//		((".TB_PREF."debtor_trans.type = ".ST_SALESINVOICE.")
//		AND ".TB_PREF."debtor_trans.due_date < '$to') AS OverDue
//    	FROM ".TB_PREF."debtor_trans
//    	WHERE ".TB_PREF."debtor_trans.tran_date >= '$from'
//		AND ".TB_PREF."debtor_trans.tran_date <= '$to'
//		AND ".TB_PREF."debtor_trans.debtor_no = ".db_escape($debtorno)."
//		AND ".TB_PREF."debtor_trans.type <> ".ST_CUSTDELIVERY."
//    	ORDER BY ".TB_PREF."debtor_trans.tran_date";
//
//    return db_query($sql,"No transactions were returned");
//}

//----------------------------------------------------------------------------------------------------

function print_customer_balances()
{
    	global $path_to_root, $systypes_array;

    	$from = $_POST['PARAM_0'];
    	$to = $_POST['PARAM_1'];
    	$fromcust = $_POST['PARAM_2'];
     	$merchant = $_POST['PARAM_3'];
    	$city = $_POST['PARAM_4'];
    	$model= $_POST['PARAM_5'];
		$no_zeros = $_POST['PARAM_6'];
    	$comments = $_POST['PARAM_7'];
		$orientation = $_POST['PARAM_8'];
		$destination = $_POST['PARAM_9'];

	if ($destination)
		include_once($path_to_root . "/reporting/includes/excel_report.inc");
	else
		include_once($path_to_root . "/reporting/includes/pdf_report.inc");

	$orientation = ($orientation ? 'L' : 'P');
	if ($fromcust == ALL_TEXT)
		$cust = _('All');
	else
		$cust = get_customer_name($fromcust);
    	//$dec = user_price_dec();



	if ($no_zeros) $nozeros = _('Yes');
	else $nozeros = _('No');


	if ($merchant== ALL_TEXT)
	{
		$merch = _('ALL');

	}

	else
		$merch=get_merchant_name($merchant);



	if ($city == ALL_TEXT)
	{
		$convert = true;

	}
	else
		$convert = false;




	if ($model == ALL_TEXT)
	{
		$convert = true;

	}
	else
		$convert = false;


	$cols = array(0, 14, 65, 100,150,170,200,300,340,370,420,450,470,520,540);
	$headers = array(_(''), _('Name'), _('Name'), _('Name'),_(''),_(''),_(''),_(''),
				_(''),_('Model'),_('S.NO.'),_('#'),('Date'),_('Status'),(''),(''),_(''));


	$aligns = array('left',	'left',	'left',	'left',	'left',	'left','left','left','left','left','left', 'left',
		'left', 'right', 'right', 'right', 'right');


	$headers2 = array(_('SNo.'), _('Customer'), _('Merch'), _('Comm'), _('Region'), _('City'), _('Address'), _('MID'), _('TID'),_('POS '),_('POS'),
		_('Sim'),_('Replacement.'),('POS'),_(''),(''),(''),_(''));



    $params =   array( 	0 => $comments,
    				    1 => array('text' => _('Period'), 'from' => $from, 		'to' => $to),
    				    2 => array('text' => _('Customer'), 'from' => $cust,   	'to' => ''),
    				    3 => array('text' => _('Currency'), 'from' => $currency, 'to' => ''),
						4 => array('text' => _('Suppress Zeros'), 'from' => $nozeros, 'to' => ''),
		                5 => array ('text' =>_('Merchant'),'from' => $merch,'to' =>''));


	$aligns2 = $aligns;
    $rep = new FrontReport(_('Replacement'), "CustomerBalances", user_pagesize(), 9, $orientation);

    if ($orientation == 'L')
    	recalculate_cols($cols);
	$cols2 = $cols;
    $rep->Font();
    $rep->Info($params, $cols, $headers, $aligns,$cols2,$headers2,$aligns2);
    $rep->NewPage();
	$result = get_sql_for_deployment_new(0, 0, $merchant, $city, $model);
		while ($myrow=db_fetch($result))
		{
			//if ($no_zeros && floatcmp($trans['TotalAmount
			//
			//llocated']) == 0) continue;
			$rep->TextCol(0, 1, $myrow['serial_number']);
			$rep->TextCol(1, 2, get_customer_name($myrow['person_id']));
			$rep->TextCol(2, 3, $myrow['merchant_name']);
			$rep->TextCol(3, 4, $myrow['commercial_name']);
			$rep->TextCol(4, 5, $myrow['region_name']);
			$rep->TextCol(5, 6, $myrow['city_name']);
			$rep->TextCol(6, 7,($myrow['address']));
			$rep->TextCol(7, 8,($myrow['mid']));
			$rep->TextCol(8, 9, $myrow['tid']);
			$rep->TextCol(9, 10, $myrow['posmodel']);
			$rep->TextCol(10, 11, $myrow['stock_id']);

			$rep->TextCol(11, 12,$myrow['sim']);
			$rep->TextCol(12, 13, sql2date($myrow['tran_date']));
			$rep->TextCol(13, 14, $myrow['status']);

			$rep->NewLine();


		}

	$rep->Line($rep->row  - 4);
	$rep->NewLine();
    	$rep->End();
}

?>
