<?php
$page_security = 'SA_SALESANALYTIC';
// ----------------------------------------------------------------
// $ Revision:	2.0 $
// Creator:	Joe Hunt
// date_:	2005-05-19
// Title:	Inventory Sales Report
// ----------------------------------------------------------------
$path_to_root="..";

include_once($path_to_root . "/includes/session.inc");
include_once($path_to_root . "/includes/date_functions.inc");
include_once($path_to_root . "/includes/data_checks.inc");
include_once($path_to_root . "/includes/banking.inc");
include_once($path_to_root . "/gl/includes/gl_db.inc");
include_once($path_to_root . "/inventory/includes/db/items_category_db.inc");

//----------------------------------------------------------------------------------------------------

print_inventory_sales();

function getTransactions()
{
	$sql = "SELECT sm.stock_id, sc.description as category, smm.tran_date,smm.tid,
				smm.p_pos,smm.person_id, m.merchant_name,
				m.address,m.commercial_name,m.contact_no,c.city_name,r.region_name,pos.pos_status_name,mi.mid 
				FROM 0_stock_moves smm 
				left join 0_stock_master sm on smm.stock_id = sm.stock_id 
				left join 0_merchant m on smm.merchant = m.id 
				left join 0_city c on m.city = c.id 
				left join 0_region r on m.region = r.id 
				left join 0_mid mi on m.id = mi.merchant_id 
				left join 0_pos_status pos on smm.pos_type = pos.id 
				left join 0_support_staff ss on smm.staff_name = ss.id 
				left join 0_stock_category sc on sm.category_id = sc.category_id 
				WHERE sm.inactive = 0";
	return db_query($sql,"oye kutty");
}

//----------------------------------------------------------------------------------------------------

function print_inventory_sales()
{
    global $path_to_root;

	//$from = $_POST['PARAM_0'];
	//$to = $_POST['PARAM_1'];
//    $category = $_POST['PARAM_2'];
//    $location = $_POST['PARAM_3'];
//    $fromcust = $_POST['PARAM_4'];
//	$comments = $_POST['PARAM_5'];
	//$orientation = $_POST['PARAM_6'];
	$destination = $_POST['PARAM_7'];
	if ($destination)
		include_once($path_to_root . "/reporting/includes/excel_report.inc");
	else
		include_once($path_to_root . "/reporting/includes/pdf_report.inc");

	$orientation = 'L';
    $dec = user_price_dec();

	/*if ($category == ALL_NUMERIC)
		$category = 0;
	if ($category == 0)
		$cat = _('All');
	else
		$cat = get_category_name($category);

	if ($location == '')
		$loc = _('All');
	else
		$loc = get_location_name($location);

	if ($fromcust == '')
		$fromc = _('All');
	else
		$fromc = get_customer_name($fromcust);*/

	$cols = array(0, 30, 75, 110, 160, 210, 270, 320, 370, 400, 440, 480, 530, 600);

	$headers = array(_('Serial No.'), _('MID'), _('TID'), _('M_Name'),
		_('Phone Number'), _('Deployment Date'), _('SerialNumber'),
		_('AssetCategory'), _('Region'), _('AssetLocation'), _('AssetType'), _('Address'));


	$aligns = array('left',	'left',	'left', 'left', 'left', 'left', 'left', 'left', 'left');

    $params =   array( //	0 => $comments,
    				 //   1 => array('text' => _('Period'),'from' => $from, 'to' => $to),
    				 //   2 => array('text' => _('Category'), 'from' => $cat, 'to' => ''),
    				//    3 => array('text' => _('Location'), 'from' => $loc, 'to' => ''),
    				  //  4 => array('text' => _('Customer'), 'from' => $fromc, 'to' => '')
		);

    $rep = new FrontReport(_('Inventory Sales Report'), "InventorySalesReport", user_pagesize(), 9, $orientation);
   	if ($orientation == 'L')
    	recalculate_cols($cols);

    $rep->Font();
    $rep->Info($params, $cols, $headers, $aligns);
    $rep->NewPage();

	$serial_no = 0;
	$res = getTransactions();

	while ($trans = db_fetch($res))
	{
		$serial_no ++;
		$rep->TextCol(0, 1, $serial_no);
		$rep->TextCol(1, 2, $trans['mid']);
		$rep->TextCol(2, 3, $trans['tid']);
		$rep->TextCol(3, 4, $trans['merchant_name']);
		$rep->TextCol(4, 5, $trans['contact_no']);
		$rep->DateCol(5, 6, sql2date($trans['tran_date']));
		$rep->TextCol(6, 7, $trans['stock_id']);
		$rep->TextCol(7, 8, $trans['p_pos']);
		$rep->TextCol(8, 9, $trans['region_name']);
		$rep->TextCol(9, 10, $trans['city_name']);
		$rep->TextCol(10, 11, $trans['pos_status_name']);
		$rep->TextColLines(11, 13, $trans['address']);
		$rep->NewLine();
	}
	$rep->NewLine(2, 3);

	$rep->Line($rep->row  - 4);
	$rep->NewLine();
    $rep->End();
}

?>