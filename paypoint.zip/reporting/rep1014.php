<?php
$page_security = 'SA_CUSTPAYMREP';

// ----------------------------------------------------------------
// $ Revision:	2.0 $
// Creator:	Joe Hunt
// date_:	2005-05-19
// Title:	Customer Balances
// ----------------------------------------------------------------
$path_to_root="..";

include_once($path_to_root . "/includes/session.inc");
include_once($path_to_root . "/includes/date_functions.inc");
include_once($path_to_root . "/includes/data_checks.inc");
include_once($path_to_root . "/gl/includes/gl_db.inc");
include_once($path_to_root . "/sales/includes/db/customers_db.inc");

//----------------------------------------------------------------------------------------------------
print_customer_balances();
function get_sql_for_deployment_new($serial_no,$mid,$m_name,$city,$model)
{

	$sql = "SELECT @a:=@a+1 serial_number,  m.merchant_name,c.city_name,smm.tid,smm.complain,smm.complain_source
,smm.tran_date,smm.resolve_date,smm.action_taken,ss.name,
                   smm.qty,smm.	person_id ,smm.staff_name
                   ,smm.standard_cost,smm.mid
               
               FROM 0_stock_moves smm 
               left join 0_stock_master sm on smm.stock_id = sm.stock_id 
               left join 0_merchant m on smm.merchant = m.id 
               left join 0_city c on m.city = c.id 
               left join 0_region r on m.region = r.id 
               left join 0_mid mi on m.id = mi.merchant_id 
               left join 0_pos_status pos on smm.pos_type = pos.id 
               left join 0_support_staff ss on smm.staff_name = ss.id 
               left join 0_stock_category sc on sm.category_id = sc.category_id, (SELECT @a:= 0) AS a
                
                WHERE sm.inactive = 0 AND smm.form_type='CF' ";


	if($serial_no != '')
	{
		$sql.=" AND sm.stock_id='".$serial_no."'";
	}

	if($mid != '')
	{
		$sql.=" AND mi.mid='".$mid."'";
	}

	if($m_name != 0)
	{
		$sql.=" AND m.id='".$m_name."'";
	}
	if($city != -1)
	{
		$sql.=" AND c.id='".$city."'";
	}

	if($model != 0)
	{
		$sql.=" AND pos.id='".$model."'";
	}


	return db_query($sql,"No transactions were returned");
}
//trial_inquiry_controls();

//
//function get_open_balance($debtorno, $to, $convert)
//{
//	if($to)
//		$to = date2sql($to);
//
//    $sql = "SELECT SUM(IF(t.type = ".ST_SALESINVOICE.",
//    	(t.ov_amount + t.ov_gst + t.ov_freight + t.ov_freight_tax + t.ov_discount)";
//    if ($convert)
//    	$sql .= " * rate";
//    $sql .= ", 0)) AS charges,
//    	SUM(IF(t.type <> ".ST_SALESINVOICE.",
//    	(t.ov_amount + t.ov_gst + t.ov_freight + t.ov_freight_tax + t.ov_discount)";
//    if ($convert)
//    	$sql .= " * rate";
//    $sql .= " * -1, 0)) AS credits,
//		SUM(t.alloc";
//	if ($convert)
//		$sql .= " * rate";
//	$sql .= ") AS Allocated,
//		SUM(IF(t.type = ".ST_SALESINVOICE.",
//			(t.ov_amount + t.ov_gst + t.ov_freight + t.ov_freight_tax + t.ov_discount - t.alloc)";
//    if ($convert)
//    	$sql .= " * rate";
//    $sql .= ",
//    	((t.ov_amount + t.ov_gst + t.ov_freight + t.ov_freight_tax + t.ov_discount) * -1 + t.alloc)";
//    if ($convert)
//    	$sql .= " * rate";
//    $sql .= ")) AS OutStanding
//		FROM ".TB_PREF."debtor_trans t
//    	WHERE t.debtor_no = ".db_escape($debtorno)
//		." AND t.type <> ".ST_CUSTDELIVERY;
//    if ($to)
//    	$sql .= " AND t.tran_date < '$to'";
//	$sql .= " GROUP BY debtor_no";
//
//    $result = db_query($sql,"No transactions were returned");
//    return db_fetch($result);
//}
//
//function get_transactions($debtorno, $from, $to)
//{
//	$from = date2sql($from);
//	$to = date2sql($to);
//
//    $sql = "SELECT ".TB_PREF."debtor_trans.*,
//		(".TB_PREF."debtor_trans.ov_amount + ".TB_PREF."debtor_trans.ov_gst + ".TB_PREF."debtor_trans.ov_freight +
//		".TB_PREF."debtor_trans.ov_freight_tax + ".TB_PREF."debtor_trans.ov_discount + ".TB_PREF."debtor_trans.gst_wh)
//		AS TotalAmount, ".TB_PREF."debtor_trans.alloc AS Allocated,
//		((".TB_PREF."debtor_trans.type = ".ST_SALESINVOICE.")
//		AND ".TB_PREF."debtor_trans.due_date < '$to') AS OverDue
//    	FROM ".TB_PREF."debtor_trans
//    	WHERE ".TB_PREF."debtor_trans.tran_date >= '$from'
//		AND ".TB_PREF."debtor_trans.tran_date <= '$to'
//		AND ".TB_PREF."debtor_trans.debtor_no = ".db_escape($debtorno)."
//		AND ".TB_PREF."debtor_trans.type <> ".ST_CUSTDELIVERY."
//    	ORDER BY ".TB_PREF."debtor_trans.tran_date";
//
//    return db_query($sql,"No transactions were returned");
//}

//----------------------------------------------------------------------------------------------------

function print_customer_balances()
{
	global $path_to_root, $systypes_array;

	$from = $_POST['PARAM_0'];
	$to = $_POST['PARAM_1'];
	$fromcust = $_POST['PARAM_2'];
	$merchant = $_POST['PARAM_3'];
	$city = $_POST['PARAM_4'];
	$model= $_POST['PARAM_5'];
	$no_zeros = $_POST['PARAM_6'];
	$comments = $_POST['PARAM_7'];
	$orientation = $_POST['PARAM_8'];
	$destination = $_POST['PARAM_9'];
	if ($destination)
		include_once($path_to_root . "/reporting/includes/excel_report.inc");
	else
		include_once($path_to_root . "/reporting/includes/pdf_report.inc");

	$orientation = ($orientation ? 'L' : 'P');
	if ($fromcust == ALL_TEXT)
		$cust = _('All');
	else
		$cust = get_customer_name($fromcust);
	//$dec = user_price_dec();



	if ($no_zeros) $nozeros = _('Yes');
	else $nozeros = _('No');


	if ($merchant== ALL_TEXT)
	{
		$merch = _('ALL');

	}

	else
		$merch=get_merchant_name($merchant);



	if ($city == ALL_TEXT)
	{
		$convert = true;

	}
	else
		$convert = false;


	if ($model == ALL_TEXT)
	{
		$convert = true;

	}
	else
		$convert = false;


	$cols = array(0, 18, 60,100,145,170,210,260,300,350,390,400,460,480, 465,490,510);
	$headers = array(_(''), _('Name'), _('Name'), _(''),_(''),_(''),
		 	_(''),_('Source'),_('Date'),_('Date'),(''),_('Taken'),(''),(''),_('StaffName'),(''),('Quantity'));


	$aligns = array('left',	'left',	'left',	'left',	'left',	'left','left','left','left','left','left', 'left',
		'left', 'right', 'right', 'right', 'right');


	$headers2 = array(_('SNo.'), _('Customer'), _('Merchant'), _('City'), _('MID'), _('TID'),_('Complains '),_('Complain'),
		_('Complain'),_('Resolve '),(''),_('Action'),(''),(''),_('Support'),(''),_('Rolls'));



    $params =   array( 	0 => $comments,
    				    1 => array('text' => _('Period'), 'from' => $from, 		'to' => $to),
    				    2 => array('text' => _('Customer'), 'from' => $cust,   	'to' => ''),
    				    3 => array('text' => _('Currency'), 'from' => $currency, 'to' => ''),
						4 => array('text' => _('Suppress Zeros'), 'from' => $nozeros, 'to' => ''));


	$aligns2 = $aligns;
    $rep = new FrontReport(_('Complain'), "CustomerBalances", user_pagesize(), 9, $orientation);

    if ($orientation == 'L')
    	recalculate_cols($cols);
	$cols2 = $cols;
    $rep->Font();
    $rep->Info($params, $cols, $headers, $aligns,$cols2,$headers2,$aligns2);
    $rep->NewPage();
	$result = get_sql_for_deployment_new(0,0,$merchant,$city,$model);
		while ($myrow=db_fetch($result))
		{

			//if ($no_zeros && floatcmp($trans['TotalAmount
			//
			//llocated']) == 0) continue;

			$rep->TextCol(0, 1, $myrow['serial_number']);
			$rep->TextCol(1, 2, get_customer_name($myrow['person_id']));
			$rep->TextCol(2, 3, $myrow['merchant_name']);

			$rep->TextCol(3, 4, $myrow['city_name']);
			$rep->TextCol(4, 5,($myrow['mid']));
			$rep->TextCol(5, 6,($myrow['tid']));
			$rep->TextCol(6, 7, $myrow['complain']);
			$rep->TextCol(7, 8, $myrow['complain_source']);
			$rep->TextCol(8, 9,sql2date( $myrow['tran_date']));

			$rep->TextCol(9, 10,sql2date($myrow['resolve_date']));
			$rep->TextCol(11, 12, $myrow['action_taken']);
			$rep->TextCol(12, 13, ($myrow['name']));
			$rep->TextCol(15, 15, $myrow['qty']);



			$rep->NewLine();


		}

	$rep->Line($rep->row  - 4);
	$rep->NewLine();
    	$rep->End();
}

?>
