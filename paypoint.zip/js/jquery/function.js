
/*
*
*  To Trim out the space of the object
*  @param obj	-	object
*  @return		-	trim object
*  @Authors		-	tclim
*  @Date  		-	06112005
*/
function trim(obj)
{
	// trim the leading spaces
	var vcount = 0;
	for (var i = 0; i < obj.length; i++)
	{
		if ((obj.charAt(i)) != " ")
			break;
		else
			vcount++;
	}
	obj = obj.substring(vcount, obj.length);

	// trim the trailing spaces
	vcount = 0;
	for (var i = obj.length - 1; i >= 0; i--)
	{
		if ((obj.charAt(i)) != " ")
			break;
		else
			vcount++;
	}
	obj = obj.substring(0, obj.length - vcount);

	return obj;
} // trim

function ValidEmailAddress(obj)
{
	var ValidEmail = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
	return ValidEmail.test(obj);
}

function IsNumericValue(obj,objname) {

 var iChars = "0123456789.";

  if (obj.indexOf(" ") != -1) {
  	 	return (objname + " cannot have spacing characters.\n");
  }

  for (var i = 0; i < obj.length; i++) {
  	if (iChars.indexOf(obj.charAt(i)) == -1) {
  	 	return (objname + " must be numeric only.\n");
  	}
  }  
  return "";
	
}

function ValidSpecialChars(obj,objname) {

  var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";


  if (obj.indexOf(" ") != -1) {
  	 	return (objname + " cannot have spacing characters.\n");
  }

  for (var i = 0; i < obj.length; i++) {
  	if (iChars.indexOf(obj.charAt(i)) != -1) {
  	 	return (objname + " cannot have special characters.\n");
  	}
  }  
  return "";
  
}

function CheckValidInputChars(obj,objname) {

  var iChars = "!#$%^&*()+=[]\';,./{}|\":<>?";

  for (var i = 0; i < obj.length; i++) {
  	if (iChars.indexOf(obj.charAt(i)) != -1) {
  	 	return (objname + " cannot have special characters.\n");
  	}
  }  
  return "";
  
}

function BookmarkSite(title,url)
{
	if (document.all) {
		window.external.AddFavorite(url,title);
	} else if (window.sidebar) {
		window.sidebar.addPanel(title,url,"");
	}
}