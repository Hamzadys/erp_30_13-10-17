<?php
$page_security = 'SA_GLTRANSVIEW';
$path_to_root = "../..";
include_once($path_to_root . "/includes/session.inc");

page(_($help_context = "General Ledger Transaction Details"), true);

include_once($path_to_root . "/includes/date_functions.inc");
include_once($path_to_root . "/includes/ui.inc");

include_once($path_to_root . "/gl/includes/gl_db.inc");

if (!isset($_GET['type_id']) || !isset($_GET['trans_no']))
{ /*Script was not passed the correct parameters */

	display_note(_("The script must be called with a valid transaction type and transaction number to review the general ledger postings for."));
	end_page();
}

start_table(TABLESTYLE3, "width=50% " );

end_table(1);

function get_payment_voucher_check($trans_no,$type)
{
	$sql = "SELECT cheque_num FROM ".TB_PREF."debtor_trans WHERE 	trans_no=".db_escape($trans_no)." AND type=$type";

	$result = db_query($sql, "could not get customer");

	$row = db_fetch_row($result);

	return $row[0];
}
function display_gl_heading($myrow)
{
	global $systypes_array;
	$trans_name = $systypes_array[$_GET['type_id']];
	start_table(TABLESTYLE_NOBORDER, "width=50% ");
	echo '<img src="../../company/0/images/pJ5KRX.png"alt="Smiley face" width="210" height="45" align="center">';
	echo "</br>";
	echo "</br>";


	if($_GET['type_id']==2)
	{
		echo "<font size='4'>Bank Receipt Voucher</font>";
	}
	elseif($_GET['type_id']==1)
	{
		echo "<font style='text-decoration: underline' size='2'>Bank Payment Voucher</font>";
		echo "<br>";
	}
	elseif($_GET['type_id']==0)
	{
		echo "<font size='4'>Journal Voucher</font>";
		echo "<br>";
		echo "<br>";
	}
	elseif($_GET['type_id']==20)
	{
		echo "<font size='4'>Vendor Journal Voucher</font>";
		echo "<br>";
		echo "<br>";
	}
	elseif($_GET['type_id']==4)
	{
		echo "<font size='4'>Funds Transfer</font>";
		echo "<br>";
		echo "<br>";
	}
	elseif($_GET['type_id']==44)
	{
		echo "<font size='4'>Cash Payment Voucher</font>";
		echo "<br>";
		echo "<br>";
	}
	elseif($_GET['type_id']==45)
	{
		echo "<font size='4'>Cash Receipt Voucher</font>";
		echo "<br>";
		echo "<br>";
	}
	elseif($_GET['type_id']==22)
	{
		echo "<font size='4'>Supplier Payment Voucher</font>";
		echo "<br>";
		echo "<br>";
	}
	else
	{
		echo "<font size='4'>Bank Payment Voucher</font>";
		echo "<br>";
		echo "<br>";

	}
	$yearOnly = date('Y', strtotime(begin_fiscalyear()));
	$yearOnly1 = date('Y', strtotime(end_fiscalyear()));
	start_table(TABLESTYLE, "width=75%");
	echo

		"<table dir='auto' style='margin-top: 0px; ; margin-bottom: ' bgcolor='#fff' height='100' width='80%' align=''; >
	<tr>
	<td align='right' style=''>
	</td>
	</div>
	
	<tr>
	<td align='left'>
    <label>Date :</label><span style='font-weight:bold;margin-left:34px; '>".sql2date($myrow["tran_date"])."</span>
    </td>
    <td align='right'>
    <label style='margin-right:13px'>Year : </label><span style='font-weight:bold;'>".$yearOnly." To ".$yearOnly1."</span>
	</td>
	</tr>	
	<tr>
	<td align='left'>
  	<label>Person/Item </label><span style='font-weight:bold'>".payment_person_name($myrow["person_type_id"],$myrow["person_id"])."</span>
	</td>
	<td align='right'>
	<label>Print Date: </label><span style='font-weight:bold;'>  ".sql2date(date("Y/m/d"))."</span>
    </td>
    </tr>
    <tr>
     <td align='left'>
     Reference # <span style='font-weight:bold'>".($myrow["reference"])."</span>
	</td>
	</tr>	
</table>
";


//	start_row();
//	label_cell(_("Date : ")."   ".(sql2date($myrow["tran_date"]))."  ".(_("Year : ")."".("2015 To 2016")), "colspan=4");
//	end_row();
//	start_row();
//	label_cell(_("Person/Item : ")."   ".("Tasnim Majid"), "colspan=4");
//	end_row();
//	start_row();
//	label_cell(_("Reference #: ")."  ".(sql2date($myrow["reference"])), "colspan=4");
//	end_row();


//label_cell(sql2date($myrow["tran_date"]), "colspan=2");

	end_row();
//	$th = array(_("General Ledger Transaction Details"), _("Reference"),
//		_("Date"), _("Person/Item"));

//	table_header($th);
//	start_row();
//	label_cell("$trans_name #" . $_GET['trans_no']);
//	label_cell($myrow["reference"]);
//	label_cell(sql2date($myrow["tran_date"]));
//	label_cell(payment_person_name($myrow["person_type_id"],$myrow["person_id"]));
//	end_row();

	//comments_display_row($_GET['type_id'], $_GET['trans_no']);

	end_table(1);
}
$result = get_gl_trans_new($_GET['type_id'], $_GET['trans_no']);

if (db_num_rows($result) == 0)
{
	echo "<p><center>" . _("No general ledger transactions have been created for") . " " .$systypes_array[$_GET['type_id']]." " . _("number") . " " . $_GET['trans_no'] . "</center></p><br><br>";
	end_page(true);
	exit;
}

/*show a table of the transactions returned by the sql */
$dim = get_company_pref('use_dimension');

if ($dim == 2)
	$th = array(_("Account Code"), _("Account Name"), _("Dimension")." 1", _("Department")." ",
		_("Debit"), _("Credit"), _("Cheque #"),_("Narration"));
else if ($dim == 1)
	$th = array(_("Account Code"), _("Account Name"), _("Dimension"),
		_("Debit"), _("Credit"), _("Cheque #"),_("Narration"));
else
	$th = array(_("Account Code"), _("Account Name"),
		_("Debit"), _("Credit"), _("Cheque #"),_("Narration"));





$k = 0; //row colour counter
$heading_shown = false;

$credit = $debit = 0;
while ($myrow = db_fetch($result))
{
	if ($myrow['amount'] == 0) continue;

	if (!$heading_shown)
	{
		display_gl_heading($myrow);
		start_table(TABLESTYLE_NOBORDER, "width=80%","6","0");
		table_header($th);
		$heading_shown = true;
	}

//	alt_table_row_color($k);


	label_cell($myrow['account']);
	label_cell($myrow['account_name']);
	if ($dim >= 1)
		label_cell(get_dimension_string($myrow['dimension_id'], true));
	if ($dim > 1)
		label_cell(get_dimension_string($myrow['dimension2_id'], true));

	display_debit_or_credit_cells($myrow['amount']);
//if($_GET['type_id']==12)
//{
//label_cell(get_payment_voucher_check($_GET['trans_no'],$_GET['type_id']));
//}
//elseif($_GET['type_id']==0)
//{
//label_cell('');
//}
//else
//{
	comments_display_cell_123($_GET['type_id'], $_GET['trans_no'],$myrow['account']);
//
//}
if($_GET['type_id']==10 || $_GET['type_id']==20)
{
	label_cell('');
	comments_display_cell($_GET['type_id'], $_GET['trans_no'],$myrow['account']);
}
	//display_error($_GET['type_id'].'-'.$_GET['trans_no'].'-'.$myrow['account']);
	//label_cell();

	if ($myrow['amount'] > 0 )
		$debit += $myrow['amount'];
	else
		$credit += $myrow['amount'];
//if (is_numeric($myrow['memo_'])) continue;
if($_GET['type_id']!=4 && $_GET['type_id']!=22 && $_GET['type_id']!=12){
	label_cell($myrow['memo_']);}
else{
label_cell($myrow['cmnt_']);}



	end_row();

}
if ($heading_shown)
{

	start_row("class='inquirybg' style='font-weight:bold'");
	label_cell(_("Total"), "colspan=2;border=1");
	if ($dim >= 1)
		label_cell('');
	if ($dim > 1)
		label_cell('');
	amount_cell($debit);
	amount_cell(-$credit);
	label_cell('');
	end_row();
	end_table(1);
}


//end of while loop

is_voided_display($_GET['type_id'], $_GET['trans_no'], _("This transaction has been voided."));

end_page(true, true, false, $_GET['type_id'], $_GET['trans_no']);

?>

<table style="margin-top: 50px" bgcolor="#fff" height="100" width="70" align="center" cellspacing="16" >
	<tr>
		<td>
			__________________
		</td>

		<td>__________________
		</td>

		<td >_________________
		</td>

		<td>__________________
		</td>

	</tr>
	<tr>
		<td align="center">
			<span style="font-weight:bold">Aun Ali</span>

		</td>
		<td align="center">
			<span style="font-weight:bold">CEO</span>

		</td>
		<td align="center">
			<span style="font-weight:bold">Director</span>

		</td>
		<td align="center"  FONT SIZE="5">
			<span style="font-weight:bold">Receive By</span>

		</td>
	</tr>
</table>