<?php
/*
Login attempts info.
*/
$login_faillog = array (
  0 => 
  array (
    '103.12.120.180' => 0,
    'last' => '',
  ),
  1 => 
  array (
    '::1' => 0,
    'last' => '',
  ),
  5 => 
  array (
    '113.203.151.116' => 0,
    'last' => '',
  ),
);
