<?php
$page_security = 'SA_OPEN';
$path_to_root = "../..";
include($path_to_root . "/includes/session.inc");

$js = "";
if ($use_popup_windows)
	$js .= get_js_open_window(900, 500);
if ($use_date_picker)
	$js .= get_js_date_picker();
	
page(_($help_context = "Advance"), @$_REQUEST['popup'], false, "", $js);

//page(_($help_context = "Leave"), $js);

include($path_to_root . "/payroll/includes/db/advance_db.inc");
include_once($path_to_root . "/modules/payroll/includes/ui/ui_lists.inc");
include($path_to_root . "/payroll/includes/db/gl_setup_db.inc"); 
include($path_to_root . "/includes/ui.inc");



simple_page_mode(true);


if ($Mode=='ADD_ITEM' || $Mode=='UPDATE_ITEM') 
{

	$input_error = 0;

	if (strlen($_POST['emp_id']) == 0) 
	{
		$input_error = 1;
		display_error(_("The Employee Name cannot be empty."));
		set_focus('emp_id');
	}
	if (!is_numeric($_POST['amount']))
	{
		$input_error = 1;
		display_error( _("Value must be numeric."));
		set_focus('amount');
	}
	if (!is_numeric($_POST['payment_shedule']))
	{
		$input_error = 1;
		display_error( _("Value must be numeric."));
		set_focus('payment_shedule');
	}
	if(strlen($_POST['payment_shedule']) >= 120)
	{
		$input_error = 1;
		display_error( _("Plz select less than 120 valu"));
		set_focus('payment_shedule');
	}


	/*	if (!is_date($_POST['to_date']))
	{
		display_error( _("Invalid END date "));
		set_focus('to_date');
		return false;
	}
	
	if (strlen($_POST['leave_type']) == 0) 
	{
		$input_error = 1;
		display_error(_("The Leave cannot be empty."));
		set_focus('emp_id');
	}
	$date1=$_POST['from_date'];
	$date2=$_POST['to_date'];
	if ($_POST['to_date']<$_POST['from_date']) 
	{
		$input_error = 1;
		display_error(_("From date should be less than To date ."));
		set_focus('to_date');
		
	}
	$get_duplication=get_emp_info_no($_POST['emp_id'],$_POST['from_date']);
   if($get_duplication>0)
    {
	$input_error = 1;
	display_error(_("Already Exist"));
    }*/
	if ($input_error != 1)
	{
		//$login_date = strtotime($_POST['from_date']); // change x with your login date var
       // $current_date = strtotime($_POST['to_date']); // change y with your current date var
       // $datediff = $current_date - $login_date;
       // $days = floor($datediff/(60*60*24));
		//$days1= $days+1;
 
    	if ($selected_id != -1) 
    	{
    		//update_advance($selected_id, $_POST['date'], $_POST['emp_id'], $_POST['amount'], $_POST['type'], $_POST['remarks'],$_POST['approve'],$_POST['payroll_id'],$_POST['payment_shedule'],$_POST['payment']);
			//$note = _('Selected Advance  has been updated');
    	} 
    	else 
    	{
    		add_advance( $_POST['date'], $_POST['emp_id'], $_POST['amount'], $_POST['type'], $_POST['remarks'],$_POST['approve'],       		$_POST['payroll_id'],$_POST['payment_shedule'],$_POST['payment']);
			$note = _('New Advance  has been added');
    	}
    
		display_notification($note);    	
		$Mode = 'RESET';
	}
} 

if ($Mode == 'Delete')
{

	$cancel_delete = 0;

	// PREVENT DELETES IF DEPENDENT RECORDS IN 'debtors_master'

	if (key_in_foreign_table($selected_id, 'cust_branch', 'group_no'))
	{
		$cancel_delete = 1;
		display_error(_("Cannot delete this Advance because customers have been created using this group."));
	} 
	if ($cancel_delete == 0) 
	{
		delete_advance($selected_id);
		display_notification(_('Selected Advance  has been deleted'));
	} //end if Delete group
	$Mode = 'RESET';
} 

if ($Mode == 'RESET')
{
	$selected_id = -1;
	$sav = get_post('show_inactive');
	unset($_POST);
	if ($sav) $_POST['show_inactive'] = 1;
}



function handle_delete($selected_id)
{
	delete_advance($selected_id);
   display_notification(_("Advance record has been deleted."));	
}

if (isset($_POST['delete'])) 
{		
	handle_delete($_POST['id']);
}
function handle_update($selected_id)
{
	update_advance($selected_id,$_POST['date'],$_POST['emp_id'],$_POST['amount'],$_POST['type'],$_POST['remarks'],$_POST['approve'],$_POST['payroll_id'],$_POST['payment_shedule'],$_POST['payment']);
$approval11=$_POST['approve'];
if($approval11==1)
{
			global $Refs;
            $advance_amount=$_POST['amount'];
			$shedule1=$_POST['payment_shedule'];
            $payment_permonth1=($advance_amount/$shedule1);
			$shedule_payment_month=round2($payment_permonth1);
			
			$employee_id=$_POST['emp_id'];
			$employee_name=get_employee_name($employee_id);
			$id = get_next_trans_no(ST_JOURNAL);
			$ref = $Refs->get_next(ST_JOURNAL);
			$memo = "Advance paid to $employee_name amounting to $advance_amount, payment schedule $shedule_payment_month per month";
			$advance_receivable_account=get_sys_pay_pref('advance_receivable');
			$payment_account=get_sys_pay_pref('payment');
			
			

			add_gl_trans(ST_JOURNAL, $id, $_POST['date'], $advance_receivable_account,'', '', $memo, $advance_amount);
			add_gl_trans(ST_JOURNAL, $id, $_POST['date'], $payment_account,'','', $memo, -$advance_amount);
							
			add_audit_trail(ST_JOURNAL, $id, $_POST['date']);
			add_comments(ST_JOURNAL, $id, $_POST['date'], $memo);
			$Refs->save(ST_JOURNAL, $id, $ref);	
}
   display_notification(_("Advance record has been updated. JV Reference $ref."));	
}

	if (isset($_POST['update'])) 
{		
	handle_update($_POST['id']);
}
///=======================================================

//$result = get_emp_leave_types(check_value('show_inactive'));
$id=$_GET['id'];
//echo $id;
start_form();

//-------------------------------------------------------------------------------------------------

start_table(TABLESTYLE2);

//if ($selected_id != -1) 
//{
 	//if ($Mode == 'Edit') {
		//editing an existing group
		$myrow = get_advance($_GET['id']);

		$_POST['date']  = sql2date($myrow["date"]);
		$_POST['emp_id']  = $myrow["emp_id"];
		$_POST['amount']  = $myrow["amount"];
		$_POST['type']  = $myrow["type"];
		$_POST['remarks']  = $myrow["remarks"];
		$_POST['approve']  = $myrow["approve"];
		$_POST['payroll_id']  = $myrow["payroll_id"];
		$_POST['payment_shedule']  = $myrow["payment_shedule"];
		//$_POST['payment']  = $myrow["payment"];
		
	//}
	hidden("payment", $payment_permonth);
	hidden("selected_id", $selected_id);
	hidden("id", $id);

	//label_row(_("ID"), $myrow["id"]);
//} 
/*
	$d1 = new DateTime($_POST['from_date']);
    $d2 = new DateTime($_POST['to_date']);
    $interval = $d1->diff($d2);

echo $interval->format('%R%a days');*/
//
$approval=$_POST['approve'];
 $amount=$_POST['amount'];
 $shedule=$_POST['payment_shedule'];
$payment_permonth=($amount/$shedule);
//echo $approval;
employee_list_row(_("Employee Name:"), 'emp_id', $_POST['emp_id'],true);
date_row(_("Date"),'date', null,null, 0, 0, 0, null, true); 
text_row("Amount", 'amount', null, 10, 10);
text_row(_("Deduction months:"), 'payment_shedule', null, 5, 5);	 
textarea_row(_("Remarks:"), 'remarks', null, 35, 5); 

hidden("payment", $payment_permonth);
//hidden("no_of_leave",$interval->format('%R%a days')); 
//hidden("no_of_leave",floor($datediff/(60*60*24)));
end_table(1);





	if($id==0)
	{
		submit_add_or_update_center(-1, '', 'both');
	}
	else
	{
		start_table(TABLESTYLE2);
		if($approval==0)
		{
		approve_list_row(_("Approval:"),'approve', $selected_id=null, $name_yes="", $name_no="", $submit_on_change=false);
		gl_all_accounts_list_row(_("Advance Receivable Account:"), 'advance_receivable', get_sys_pay_pref('advance_receivable'));
		gl_all_accounts_list_row(_("Payment Account:"), 'payment_account', get_sys_pay_pref('payment'));
		//echo $payment_shedule;
		label_cell("Per month deduction");
	  	label_cell( round2($payment_permonth));
		submit_center_first('update', _("Update"), '', '', true);
	   submit_center_last('delete', _("Delete"), '', '', true);
		}
		else
		{
			submit_center_last('delete', _("Delete"), '', '', true);
		}
	  // text_row_ex(_("Payment(Per Month):"), 'payment', 10, null, null, $_POST['emp_id'] );
	  
	 
	   
     end_table(1);
	}




end_form();

end_page();
?>
