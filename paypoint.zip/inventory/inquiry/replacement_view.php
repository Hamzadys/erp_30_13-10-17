<?php
$path_to_root = "../..";

include_once($path_to_root . "/includes/db_pager.inc");
include_once($path_to_root . "/includes/session.inc");
include_once($path_to_root . "/sales/includes/sales_ui.inc");
include_once($path_to_root . "/reporting/includes/reporting.inc");

$page_security = 'SA_ITEMSTRANSVIEW';

set_page_security( @$_POST['order_view_mode'],
    array(	'OutstandingOnly' => 'SA_SALESDELIVERY',
        'InvoiceTemplates' => 'SA_SALESINVOICE'),
    array(	'OutstandingOnly' => 'SA_SALESDELIVERY',
        'InvoiceTemplates' => 'SA_SALESINVOICE')
);

if (get_post('type'))
    $trans_type = $_POST['type'];
elseif (isset($_GET['type']) && $_GET['type'] == ST_SALESQUOTE)
    $trans_type = ST_SALESQUOTE;
else
    $trans_type = ST_SALESORDER;

if ($trans_type == ST_SALESORDER)
{
    if (isset($_GET['OutstandingOnly']) && ($_GET['OutstandingOnly'] == true))
    {
        $_POST['order_view_mode'] = 'OutstandingOnly';
        $_SESSION['page_title'] = _($help_context = "Search Outstanding Sales Orders");
    }
    elseif (isset($_GET['InvoiceTemplates']) && ($_GET['InvoiceTemplates'] == true))
    {
        $_POST['order_view_mode'] = 'InvoiceTemplates';
        $_SESSION['page_title'] = _($help_context = "Search Template for Invoicing");
    }
    elseif (isset($_GET['DeliveryTemplates']) && ($_GET['DeliveryTemplates'] == true))
    {
        $_POST['order_view_mode'] = 'DeliveryTemplates';
        $_SESSION['page_title'] = _($help_context = "Select Template for Delivery");
    }
    elseif (!isset($_POST['order_view_mode']))
    {
        $_POST['order_view_mode'] = false;
        $_SESSION['page_title'] = _($help_context = "Search All Sales Orders");
    }
}
else
{
    $_POST['order_view_mode'] = "Quotations";
    $_SESSION['page_title'] = _($help_context = "Search All Replacements");
}

if (!@$_GET['popup'])
{
    $js = "";
    if ($use_popup_windows)
        $js .= get_js_open_window(900, 600);
    if ($use_date_picker)
        $js .= get_js_date_picker();
    page($_SESSION['page_title'], false, false, "", $js);
}

if (isset($_GET['selected_customer']))
{
    $selected_customer = $_GET['selected_customer'];
}
elseif (isset($_POST['selected_customer']))
{
    $selected_customer = $_POST['selected_customer'];
}
else
    $selected_customer = -1;

//---------------------------------------------------------------------------------------------

if (isset($_POST['SelectStockFromList']) && ($_POST['SelectStockFromList'] != "") &&
    ($_POST['SelectStockFromList'] != ALL_TEXT))
{
    $selected_stock_item = $_POST['SelectStockFromList'];
}
else
{
    unset($selected_stock_item);
}
//---------------------------------------------------------------------------------------------
//	Query format functions
//


function get_sql_for_deployment($serial_no,$mid,$m_name, $from='', $to='',$city,$model)
{

    $sql = "SELECT @a:=@a+1 serial_number, m.merchant_name,m.commercial_name, r.region_name,
      c.city_name,m.address,smm.tid,pm.pos_status_name as posmodel,smm.stock_id,smm.sim,smm.tran_date,pos.pos_status_name as status,
                   smm.p_pos,smm.qty,smm.remarks ,smm.staff_name,pos.pos_status_name
                   ,smm.stock_id2,smm.tid2,smm.person_id,smm.mid
               
               FROM 0_stock_moves smm 
               left join 0_stock_master sm on smm.stock_id = sm.stock_id 
               left join 0_merchant m on smm.merchant = m.id 
               left join 0_city c on m.city = c.id 
               left join 0_region r on m.region = r.id 
               left join 0_pos_status pos on smm.pos_type = pos.id 
               left join 0_pos_model pm on smm.pos_type = pm.id 
               left join 0_support_staff ss on smm.staff_name = ss.id 
               left join 0_stock_category sc on sm.category_id = sc.category_id, (SELECT @a:= 0) AS a
                
                WHERE  smm.form_type='RF' ";

    if($serial_no !='')
    {
        $sql.=" AND sm.stock_id='".$serial_no."'";
    }

    if($mid !='')
    {
        $sql.=" AND mi.mid='".$mid."'";
    }

    if($m_name !='')
    {
        $sql.=" AND m.id='".$m_name."'";
    }
    if($city !='')
    {
        $sql.=" AND c.id='".$city."'";
    }
    if($model !='')
    {
        $sql.=" AND pm.id='".$model."'";
    }
    $date_after = date2sql($from);
    $date_before = date2sql($to);

    $sql .=  " AND smm.tran_date >= '$date_after'"
        ." AND smm.tran_date <= '$date_before'";


    return $sql;
}
function check_overdue($row)
{
    /*	global $trans_type;
        if ($trans_type == ST_SALESQUOTE)
            return (date1_greater_date2(Today(), sql2date($row['delivery_date'])));
        else
            return ($row['type'] == 0
                && date1_greater_date2(Today(), sql2date($row['ord_date']))
                && ($row['TotDelivered'] < $row['TotQuantity']));*/
}

function view_link($dummy, $order_no)
{
    global $trans_type;
    return  get_customer_trans_view_str($trans_type, $order_no);
}
function get_staff_name_for_view($row)
{
    $sql ="SELECT name from 0_support_staff where id=".$row['staff_name'];
    $db = db_query($sql,'sfd');
    $ft = db_fetch($db);
    return $ft[0];
}

function get_tid_name_for_view($row)
{
    $sql ="SELECT tid from 0_allocated_tid where id=".$row['tid'];
    $db = db_query($sql, "");
    $ft = db_fetch($db);
    return $ft[0];
}
function get_mid_stat($row)
{
    $sql = "SELECT mid FROM ".TB_PREF."mid WHERE id=".db_escape($row['mid']);

    $result = db_query($sql, "could not get customer");

    $row = db_fetch_row($result);

    return $row[0];
}
function prt_link($row)
{
    global $trans_type;
    return print_document_link($row['order_no'], _("Print"), true, $trans_type, ICON_PRINT);
}

function edit_link($row)
{
    if (@$_GET['popup'])
        return '';
    global $trans_type;
    $modify = ($trans_type == ST_SALESORDER ? "ModifyOrderNumber" : "ModifyQuotationNumber");
    return pager_link( _("Edit"),
        "/sales/sales_order_entry.php?$modify=" . $row['order_no'], ICON_EDIT);
}

function dispatch_link($row)
{
    global $trans_type;
    if ($trans_type == ST_SALESORDER)
        return pager_link( _("Dispatch"),
            "/sales/customer_delivery.php?OrderNumber=" .$row['order_no'], ICON_DOC);
    else
        return pager_link( _("Sales Order"),
            "/sales/sales_order_entry.php?OrderNumber=" .$row['order_no'], ICON_DOC);
}

function invoice_link($row)
{
    global $trans_type;
    if ($trans_type == ST_SALESORDER)
        return pager_link( _("Invoice"),
            "/sales/sales_order_entry.php?NewInvoice=" .$row["order_no"], ICON_DOC);
    else
        return '';
}

function delivery_link($row)
{
    return pager_link( _("Delivery"),
        "/sales/sales_order_entry.php?NewDelivery=" .$row['order_no'], ICON_DOC);
}

function order_link($row)
{
    return pager_link( _("Sales Order"),
        "/sales/sales_order_entry.php?NewQuoteToSalesOrder=" .$row['order_no'], ICON_DOC);
}

function tmpl_checkbox($row)
{
    global $trans_type;
    if ($trans_type == ST_SALESQUOTE)
        return '';
    if (@$_GET['popup'])
        return '';
    $name = "chgtpl" .$row['order_no'];
    $value = $row['type'] ? 1:0;

// save also in hidden field for testing during 'Update'

    return checkbox(null, $name, $value, true,
        _('Set this order as a template for direct deliveries/invoices'))
    . hidden('last['.$row['order_no'].']', $value, false);
}
//---------------------------------------------------------------------------------------------
// Update db record if respective checkbox value has changed.
//
function change_tpl_flag($id)
{
    global	$Ajax;

    $sql = "UPDATE ".TB_PREF."sales_orders SET type = !type WHERE order_no=$id";

    db_query($sql, "Can't change sales order type");
    $Ajax->activate('orders_tbl');
}
function get_customer_name_new($row)
{
    $sql = "SELECT name FROM ".TB_PREF."debtors_master WHERE debtor_no=".db_escape($row['person_id']);

    $result = db_query($sql, "could not get customer");

    $row = db_fetch_row($result);

    return $row[0];
}
$id = find_submit('_chgtpl');
if ($id != -1)
    change_tpl_flag($id);

if (isset($_POST['Update']) && isset($_POST['last'])) {
    foreach($_POST['last'] as $id => $value)
        if ($value != check_value('chgtpl'.$id))
            change_tpl_flag($id);
}

$show_dates = !in_array($_POST['order_view_mode'], array('OutstandingOnly', 'InvoiceTemplates', 'DeliveryTemplates'));
//---------------------------------------------------------------------------------------------
//	Order range form
//
if (get_post('_OrderNumber_changed') || get_post('_OrderReference_changed')) // enable/disable selection controls
{
    $disable = get_post('OrderNumber') !== '' || get_post('OrderReference') !== '';

    if ($show_dates) {
        $Ajax->addDisable(true, 'OrdersAfterDate', $disable);
        $Ajax->addDisable(true, 'OrdersToDate', $disable);
    }

    $Ajax->activate('orders_tbl');
}

if (!@$_GET['popup'])
    start_form();

start_table(TABLESTYLE_NOBORDER);
start_row();
merchant_name_list_cells(_("Mercahnt Name"),'m_name', null, false, false,true);

//ref_cells(_("S No :"), 'serial_no', '',null, '', true);
//ref_cells(_("Ref"), 'OrderReference', '',null, '', true);
if ($show_dates)
{
     date_cells(_("from:"), 'OrdersAfterDate', '', null, -30);
     date_cells(_("to:"), 'OrdersToDate', '', null, 1);
}
city_name_list_cells(_("City:"), 'city', null, false, false,true);

if($show_dates) {
    end_row();
    end_table();

    start_table(TABLESTYLE_NOBORDER);
    start_row();
}
stock_items_list_cells(_("Item:"), 'SelectStockFromList', null, true);

//mid_list_cells(_("Mercahnt Name"),'m_name', null, false, true);

text_cells(_("Type MID"), 'mid');
pos_model_name_list_cells(_("Pos Model:"), 'model', null, false, false,true);

/*if (!@$_GET['popup'])
    customer_list_cells(_("Select a customer: "), 'customer_id', null, true);
if ($trans_type == ST_SALESQUOTE)
    check_cells(_("Show All:"), 'show_all');*/

submit_cells('SearchOrders', _("Search"),'',_('Select documents'), 'default');
hidden('order_view_mode', $_POST['order_view_mode']);
hidden('type', $trans_type);

end_row();

end_table(1);
//---------------------------------------------------------------------------------------------
//	Orders inquiry table
//
$sql = get_sql_for_deployment($_POST['SelectStockFromList'],$_POST['mid'],$_POST['m_name'], @$_POST['OrdersAfterDate'], @$_POST['OrdersToDate'],$_POST['city'],$_POST['model']);

if ($trans_type == ST_SALESORDER)
    $cols = array(
        _("Order #") => array('fun'=>'view_link'),
        _("Ref"),
        _("Customer"),
        _("Branch"),
        _("Cust Order Ref"),
        _("Order Date") => 'date',
        _("Required By") =>array('type'=>'date', 'ord'=>''),
        _("Delivery To"),
        _("Order Total") => array('type'=>'amount', 'ord'=>''),
        'Type' => 'skip',
        _("Currency") => array('align'=>'center')
    );
else
    $cols = array(
        _("S.No "), // => array('fun'=>'view_link'),
          _("Customer name") => array('insert'=>true, 'fun'=>'get_customer_name_new'),
         _("Merchant Name"),// =>array('type'=>'date', 'ord'=>''),
        _("Commercial Name "),// => array('type'=>'amount', 'ord'=>''),     
        _("Region"),// => array('type'=>'amount', 'ord'=>''),
        _("City"),// => array('type'=>'amount', 'ord'=>''),
        _("Address"),// =>array('type'=>'date', 'ord'=>''),
        _("MID") => array('insert'=>true, 'fun'=>'get_mid_stat'),
        _("TID"),
        _("POS Model"),
        _("POS S.No."),
        _("SIM #"),
        _("Replacement Date") =>array('type'=>'date', 'ord'=>''),
        _('POS Status'),// => array('fun'=>'get_pos_stat'),
       // _("Quantity"),
       // _("Remarks"),// => array('type'=>'amount', 'ord'=>''),
       // _("Staff Name") => array('fun'=>'get_staff_name_for_view'),
       // _("POS Type"),// => array('type'=>'amount', 'ord'=>''),
      //  _("Cost"),// => array('type'=>'amount', 'ord'=>''),
       // _("Serial NO 2"),// => array('type'=>'amount', 'ord'=>''),
       // _("Tid 2"),// => array('type'=>'amount', 'ord'=>''),

         'Type' => 'skip'
        //_("Currency") => array('align'=>'center')
    );
if ($_POST['order_view_mode'] == 'OutstandingOnly') {
    //array_substitute($cols, 3, 1, _("Cust Order Ref"));
    array_append($cols, array(
        array('insert'=>true, 'fun'=>'dispatch_link'),
        array('insert'=>true, 'fun'=>'edit_link')));

} elseif ($_POST['order_view_mode'] == 'InvoiceTemplates') {
    array_substitute($cols, 3, 1, _("Description"));
    array_append($cols, array( array('insert'=>true, 'fun'=>'invoice_link')));

} else if ($_POST['order_view_mode'] == 'DeliveryTemplates') {
    array_substitute($cols, 3, 1, _("Description"));
    array_append($cols, array(
            array('insert'=>true, 'fun'=>'delivery_link'))
    );

} elseif ($trans_type == ST_SALESQUOTE) {
    array_append($cols,array(
        //   array('insert'=>true, 'fun'=>'edit_link'),
        //   array('insert'=>true, 'fun'=>'order_link'),
        //    array('insert'=>true, 'fun'=>'prt_link')
    ));
} elseif ($trans_type == ST_SALESORDER) {
    array_append($cols,array(
        _("Tmpl") => array('insert'=>true, 'fun'=>'tmpl_checkbox'),
        array('insert'=>true, 'fun'=>'edit_link'),
        array('insert'=>true, 'fun'=>'prt_link')));
};


$table =& new_db_pager('orders_tbl', $sql, $cols);
$table->set_marker('check_overdue', _("Marked items are overdue."));

$table->width = "80%";

display_db_pager($table);
submit_center('Update', _("Update"), true, '', null);

if (!@$_GET['popup'])
{
    end_form();
    end_page();
}
?>