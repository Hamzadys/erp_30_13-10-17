<?php

class payroll_app extends application 
{
	function payroll_app() 
	{
		$this->application("payroll", _($this->help_context = "Payroll"));
	
//		$this->add_module(_("My Dashboard"));
//		$this->add_lapp_function(1, _("My &Dashboard"),
//			"modules/dashboard/dashboard.php", 'SS_DASHBOARD', MENU_INQUIRY);
	
		$this->add_extensions();
	}
}


?>