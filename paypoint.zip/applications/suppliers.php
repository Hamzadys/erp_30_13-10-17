<?php

class suppliers_app extends application 
{
	function suppliers_app() 
	{
		$this->application("AP", _($this->help_context = "&Suppliers"));

		$this->add_module(_("Transactions"));
		$this->add_lapp_function(0, _("Purchase &Orders (PO)"),
			"purchasing/po_entry_items.php?NewOrder=Yes", 'SA_PURCHASEORDER', MENU_TRANSACTION);
		$this->add_lapp_function(0, _("Good Received Note (&GRN)"),
			"purchasing/inquiry/po_search.php?", 'SA_GRN', MENU_TRANSACTION);
		//$this->add_lapp_function(0, _("&GRN"),
			//"purchasing/po_entry_items.php?NewGRN=Yes", 'SA_GRN', MENU_TRANSACTION);
	$this->add_lapp_function(0, _("Credit &Bill"),
			"purchasing/supplier_invoice.php?New=1", 'SA_SUPPLIERINVOICE', MENU_TRANSACTION);		
		
		$this->add_rapp_function(0, _("&Payments"),
			"purchasing/supplier_payment.php?", 'SA_SUPPLIERPAYMNT', MENU_TRANSACTION);
		$this->add_rapp_function(0, "","");
		$this->add_lapp_function(0, _("Cash &Bill"),
			"purchasing/po_entry_items.php?NewInvoice=Yes", 'SA_SUPPLIERINVOICE', MENU_TRANSACTION);
		$this->add_rapp_function(0, _("&Purchase Return"),
			"purchasing/supplier_credit.php?New=1", 'SA_SUPPLIERCREDIT', MENU_TRANSACTION);
		//$this->add_rapp_function(0, _("&Allocations"),
		//	"purchasing/allocations/supplier_allocation_main.php?", 'SA_SUPPLIERALLOC', MENU_TRANSACTION);

		$this->add_module(_("Reports"));
		$this->add_lapp_function(1, _("Purchase Orders Dashboard"),
			"purchasing/inquiry/po_search_completed.php?", 'SA_SUPPTRANSVIEW', MENU_INQUIRY);
		$this->add_lapp_function(1, _("Supplier Transaction Dashboard"),
			"purchasing/inquiry/supplier_inquiry.php?", 'SA_SUPPTRANSVIEW', MENU_INQUIRY);
		$this->add_lapp_function(1, "","");
		//$this->add_lapp_function(1, _("Supplier Allocation Dashboard"),
			//"purchasing/inquiry/supplier_allocation_inquiry.php?", 'SA_SUPPLIERALLOC', MENU_INQUIRY);

		$this->add_rapp_function(1, _("Print &Reports"),
			"reporting/reports_main.php?Class=1", 'SA_SUPPTRANSVIEW', MENU_REPORT);

		$this->add_module(_("Setup"));
		$this->add_lapp_function(2, _("Add &Suppliers"),
			"purchasing/manage/suppliers.php?", 'SA_SUPPLIER', MENU_ENTRY);

		$this->add_extensions();
	}
}


?>