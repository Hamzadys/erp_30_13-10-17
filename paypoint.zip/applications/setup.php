<?php

class setup_app extends application
{
	function setup_app()
	{
		$this->application("system", _($this->help_context = "S&ettings"));

		$this->add_module(_("Company Setup"));
		$this->add_lapp_function(0, _("&Company Details"),
			"admin/company_preferences.php?", 'SA_SETUPCOMPANY', MENU_SETTINGS);
		$this->add_lapp_function(0, _("&User Setup"),
			"admin/users.php?", 'SA_USERS', MENU_SETTINGS);
		$this->add_lapp_function(0, _("User &Rights Setup"),
			"admin/security_roles.php?", 'SA_SECROLES', MENU_SETTINGS);
		$this->add_lapp_function(0, _("&Configuration"),
			"admin/display_prefs.php?", 'SA_SETUPDISPLAY', MENU_SETTINGS);
		$this->add_lapp_function(0, _("&Forms Numbers"),
			"admin/forms_setup.php?", 'SA_FORMSETUP', MENU_SETTINGS);
		$this->add_rapp_function(0, _("&GST Rate"),
			"taxes/tax_types.php?", 'SA_TAXRATES', MENU_MAINTENANCE);
		$this->add_rapp_function(0, _("Customer Tax &Setup"),
			"taxes/tax_groups.php?", 'SA_TAXGROUPS', MENU_MAINTENANCE);
		$this->add_rapp_function(0, _("Item Ta&x Setup"),
			"taxes/item_tax_types.php?", 'SA_ITEMTAXTYPE', MENU_MAINTENANCE);
		$this->add_rapp_function(0, _("System Setup"),
			"admin/gl_setup.php?", 'SA_GLSETUP', MENU_SETTINGS);
		$this->add_rapp_function(0, _("&Fiscal Years"),
			"admin/fiscalyears.php?", 'SA_FISCALYEARS', MENU_MAINTENANCE);
		//$this->add_rapp_function(0, _("&Print Profiles"),
		//	"admin/print_profiles.php?", 'SA_PRINTPROFILE', MENU_MAINTENANCE);

		$this->add_module(_("Miscellaneous"));
		$this->add_lapp_function(1, _("Pa&yment Terms"),
			"admin/payment_terms.php?", 'SA_PAYTERMS', MENU_MAINTENANCE);
		$this->add_lapp_function(1, _("Shi&pping Company"),
			"admin/shipping_companies.php?", 'SA_SHIPPING', MENU_MAINTENANCE);
		$this->add_rapp_function(1, _("&POS"),
			"sales/manage/sales_points.php?", 'SA_POSSETUP', MENU_MAINTENANCE);
		//$this->add_rapp_function(1, _("&Printers"),
		//	"admin/printers.php?", 'SA_PRINTERS', MENU_MAINTENANCE);
		//$this->add_rapp_function(1, _("Contact &Categories"),
		//	"admin/crm_categories.php?", 'SA_CRMCATEGORY', MENU_MAINTENANCE);

		$this->add_module(_("Maintenance"));
		$this->add_lapp_function(2, _("&Void a Transaction"),
			"admin/void_transaction.php?", 'SA_VOIDTRANSACTION', MENU_MAINTENANCE);
		$this->add_lapp_function(2, _("View/&Print Transactions"),
			"admin/view_print_transaction.php?", 'SA_VIEWPRINTTRANSACTION', MENU_MAINTENANCE);
		$this->add_lapp_function(2, _("&Attach/Upload Documents"),
			"admin/attachments.php?filterType=20", 'SA_ATTACHDOCUMENT', MENU_MAINTENANCE);
		//$this->add_lapp_function(2, _("System &Diagnostics"),
			//"admin/system_diagnostics.php?", 'SA_OPEN', MENU_SYSTEM);

		$this->add_rapp_function(2, _("&Backup/Restore"),
			"admin/backups.php?", 'SA_BACKUP', MENU_SYSTEM);
		//$this->add_rapp_function(2, _("Create/Update &Companies"),
		//	"admin/create_coy.php?", 'SA_CREATECOMPANY', MENU_UPDATE);
		//$this->add_rapp_function(2, _("Install/Update &Languages"),
		//	"admin/inst_lang.php?", 'SA_CREATELANGUAGE', MENU_UPDATE);
		//$this->add_rapp_function(2, _("Install/Activate &Extensions"),
		//	"admin/inst_module.php?", 'SA_CREATEMODULES', MENU_UPDATE);
		//$this->add_rapp_function(2, _("Install/Activate &Themes"),
		//	"admin/inst_theme.php?", 'SA_CREATEMODULES', MENU_UPDATE);
		//$this->add_rapp_function(2, _("Install/Activate &Chart of Accounts"),
		//	"admin/inst_chart.php?", 'SA_CREATEMODULES', MENU_UPDATE);
		//$this->add_rapp_function(2, _("Software &Upgrade"),
		//	"admin/inst_upgrade.php?", 'SA_SOFTWAREUPGRADE', MENU_UPDATE);

		$this->add_extensions();
	}
}


?>